# Report structure — section-by-section template

Read this before writing the Markdown report. Adapt the headings and the analysis sections to your
domain; keep the order. Each `##` below is a report section. The example prose / legends are
illustrative — replace with the real content. The OKN federation is cross-domain, so a section like
"§7 Domain analyses" holds whatever the study needs (spatial hot-spots, category enrichment, network
tracing, exposure modelling, …).

**Group like with like.** Each kind of data belongs in exactly one section. Do not scatter the same
data type — geolocation / spatial data is the usual offender — across several sections; put all of
it in one place (one map section, one enrichment section, …) and cross-reference from elsewhere.
When an analysis would touch the same data in two spots, consolidate rather than duplicate.

**Numbers come from `stats.json`, not your keyboard.** Write every volatile / headline figure (counts,
denominators, thresholds, the tier distribution) as a `{{key}}` placeholder sourced from one
`stats.json`; the tooling fills it into the delivered `.md`, the `.html`, and the KPI cards (see the
SKILL's *Interactive HTML report* + failure-mode notes). Author the number once, in `stats.json`.

## Linking between deliverables

§8 points at the literature comparison and §11 at the reproducibility notebook. Write both as
**relative links in the `.md`** — `[<study>_literature_comparison.md](<study>_literature_comparison.md)`,
`[<study>_notebook/](<study>_notebook/<study>_notebook.ipynb)`.
The folder is the unit of delivery, so the target travels with the report: the link works from a
local folder, a zip, a shared drive, any repo, and offline.

**The `.html` does not link companion documents at all** — it names them. The HTML report is
self-contained *by design* and is the artifact people copy and email; the moment it leaves its
folder, any link to a sibling file is broken, and a reader who clicks it gets an error rather than
the document. A filename they can ask for is more useful than a dead link.

This is automatic, not something to hand-manage: `_inline` in `build_report_html.py` emits `<a>`
only for **absolute** destinations (`http(s):`, `mailto:`, in-page `#anchor`) and renders any
**relative** destination as `<code>text</code>`. So the same `.md` link gives a working link in
Markdown and a plain filename in HTML, and a rebuild can never reintroduce the broken link.
External links — DOIs, PMC, KG project pages — are absolute and stay live in both.

**Never hard-code a repository URL to dodge this.** `github.com/<org>/<repo>/blob/…` is dead for
anyone who did not commit the study to that exact repo, and if the path happens to exist there it
silently resolves to a *different* study's file.

Whichever form is used, check the target exists before delivering: the relative path on disk, and
absolute URLs by fetching them.

## Title block (before §1)

```
# <Descriptive title of the analysis / knowledge map>
### <one-line subtitle: what kind of analysis, on which OKN graphs>

**Date:** YYYY-MM-DD · **Endpoint:** OKN federated SPARQL · **Model:** <exact model id>

> **Framing (non-negotiable).** <unit of analysis> over <spatial / temporal coverage>;
> <level of inference>. <one-sentence key caveat> — e.g. *"hypothesis generation, not causal /
> clinical inference"*, or *"observational county-level associations"*, or *"model output, not
> field measurements"*. Keep this caveat attached to every downstream claim.

**Abbreviations.** Define EVERY acronym used (domain examples: PFAS = per- and polyfluoroalkyl
substances; HUC = hydrologic unit code; FDR = false-discovery rate; BMD = bone mineral density; …).
```

**`Model:` is the exact runtime model identifier** — `claude-opus-5`, `gpt-5.6-sol` — taken only from
trusted session/system metadata or supplied by the user, with a context-window variant marker
stripped (`claude-opus-5[1m]` → `claude-opus-5`). Never infer it from the assistant's product name or
from wording like *"based on GPT-5"*, and never write a family name, product name, or placeholder
(`Claude`, `GPT-5`, `Codex`, `OpenAI model`, `latest model`, `unknown`, `<model>`) — each one reads as
filled-in provenance while identifying nothing. **If you cannot determine the exact identifier, ask
the user for it** before generating the report or the reproducibility notebook; a guess, a placeholder,
and a silent omission are all worse than the question. The same string must appear in the rendered
`.html` header (automatic when the HTML is rendered from this `.md`) and in
`create_jupyter_notebook(model=…)` — `validate_okn_report.py` fails the package on a missing,
generic, or inconsistent value.

## 1. Executive summary
Headline result in 2–4 short paragraphs: the defining finding, the key quantities (with their
denominators), the top results / entities, and the one-line "what this adds". No bullet dumps.

## 2. Sources used
**Required in every report — never omit this section.** Table:
`| KG | Version | Updated | Role in this study | Join key / confidence |`. One row per KG actually
queried (if the analysis hit a KG, it gets a row); fill `Version` + `Updated` from `get_kg_version`
(release string + `last_updated` date). Format `Updated` as **YYYY-MM-DD only** (truncate the
ISO-8601 timestamp), so the reader sees how current each graph is. A report with no Sources table, or
one missing a KG the queries touched, is incomplete. **The rule is bidirectional: list a KG ONLY if
it was actually queried** (has logged queries). Never give a row — or a `sources (n)` pill — to a KG
whose contribution came from an unlogged / exploratory query or from prior knowledge; every source
and every cross-KG claim must trace to a logged query. A bridge graph credited with a join (e.g.
`ubergraph` for a DOID→MONDO equivalence) must have that query in the session log, or it is a phantom
source — remove it. (When you curate `create_jupyter_notebook`'s `supporting` set, keep every query a
credited source depends on — leaving one out trips the same phantom-source guard.)

## 3. Design & rules
**Narrate** the selection logic for a *reader*: what was included / excluded and why, the headline
thresholds, and the join keys in plain terms — plus an **inventory / cohort table rebuilt live** with
verified counts. Add the main design / overview figure here (Figure 1). **Do not restate the exact
specification here** — the replicator-grade detail (every join key, the exact backgrounds, scoring
formulas such as `1/sqrt(fanout)`) lives *only* in the **notebook's `## Replicator specification`
cell** (the first markdown cell of `create_jupyter_notebook`'s `cells`); cross-reference it ("full
specification in the reproducibility notebook") rather than duplicating it. §3 is for a reader; the spec section is for a
replicator — the same thresholds spelled out in both is drift waiting to happen.

## 4. Confidence tiers
A small table defining tiers A / B / C and what evidence each requires. Give the tier distribution.

## 5. Findings by axis
One `###` subsection per analysis axis, each ending with its figure + legend + a 1–3 sentence
interpretation of the result. Choose the axes the
question needs — examples across domains: primary signal / ranking; internal replication or a
control / deconfounder arm; spatial distribution & hot-spots (map); temporal trend; category or
group specificity; cross-KG corroboration; network centrality or dependency depth;
exposure↔outcome linkage.

## 6. Domain analyses
The domain-specific deep dives, each with a figure. Include those that apply. Examples across
the federation: category / functional enrichment; pathway or network analysis; geospatial
clustering; supply-chain or dependency tracing; flood / exposure modelling; facility or provider
inventories.

**When an analysis is a family, run every member or declare the skips.** If a deliverable has natural
members (GO *and* Reactome enrichment; several exposure media; multiple centralities), either run all
of them or **state which you RAN and which you deliberately SKIPPED, each with a one-line reason**.
"Include only those that apply" must not become a silent half-completion — a missing sub-analysis has
no loud tripwire, so an unstated omission reads as full coverage. Make it explicit.

## 7. Discussion
Synthesise the axes into a coherent picture; state the implications / recommendations / targets
(interventions, priority sites, candidate targets, mitigations — flagged by evidence strength); and
name the testable predictions or the decisions they support.

## 8. Comparison with prior work
Per-finding concordance (supported / partially / novel / contradicted), with numbered citations,
wherever a literature or authoritative reference source exists for the domain. **Name the retrieval
tool up front** (e.g. *"According to PubMed and the Paperclip corpus…"*) and **mark which central
claims were verified against full text**. Flag discrepancies as testable predictions.

**Required: a numbered per-claim table.** §8 leads with a table — one row per checked claim —
so a reader can scan every result at once instead of mining paragraphs for them:

```
| # | Claim | Concordance |
|---|---|---|
| 1 | <the claim as this analysis stated it>   | **SUPPORTED** — <what the literature shows, plus the caveat that qualifies it> |
| 2 | <…>                                      | **PARTIALLY SUPPORTED** — <which half holds, which half doesn't> |
```

- Head the third column **Concordance**, not *Verdict*: the row records how this finding and the
  prior work relate, and the same courtroom framing ruled out below for *validation* is wrong in
  a column header too.
- The **Concordance** cell opens with a bolded label from this **closed set of six — no other
  value, and no custom or compound label**. Every qualifier (analogy, framing, full-text status, a
  caveat, "with a gap", "in this framing") goes in the description after the em-dash, never in the
  label:
  - **SUPPORTED** — the prior literature agrees with the finding.
  - **PARTIALLY SUPPORTED** — agrees in part; the exceptions or caveats go in the description.
  - **CONTRADICTED** — the prior literature disagrees.
  - **MIXED** — the literature is itself divided, and the KG reproduces that disagreement.
  - **NOVEL** — no prior literature for the specific claim (incl. a KG-only data-quality observation).
  - **UNRESOLVED** — could not be verified within the search.

  Then an em-dash and the reason — a bare label is not enough; the reader must see *why* without
  opening the companion document.
- **Every Concordance cell carries a citation** — `[n]` markers resolving to §12 — or says in
  words why it has none (*"no source found"*, which is itself a NOVEL result). A
  cell that names a study in prose without a marker leaves the reader no route from the verdict
  to the paper. Derive the mapping from the companion document's per-claim PMIDs rather than from
  memory, and never cite a PMID that has no §12 entry.
- **Do not restate the table in prose.** A paragraph per verdict group ("**Supported.** …",
  "**Contradicted.** …") that walks the same findings again doubles the section's length and adds
  nothing a reader of the table needs. Everything below the table must be **cross-cutting**: the
  full-text line, the divergences paragraph, evidence gaps, an overall-confidence summary. Per-row
  supporting detail — the individual studies, their numbers, the caveats — belongs in
  `<study>_literature_comparison.md`, which is what that deliverable is for.
- **Keep the intro generic — no tallies, no marker legend.** Name the retrieval tools, say the
  claims were checked against the primary literature, and point at `<study>_literature_comparison.md`.
  Do **not** explain the full-text-verified marker ("claims marked *full-text-verified* were checked
  against the article text") — every marked entry already carries it inline, so the sentence just
  duplicates it, here and in §12. Do **not** open with counts ("47 checkable claims: 28
  supported, 15 novel, 4 contradicted… 74 unique PMIDs"): the reader has to reconcile them against a
  table with a different number of rows, and every one is a number to re-verify whenever the
  analysis changes. **The table is the count**, and the companion document is the per-claim record.
  Referring to a specific row by number ("Claim 7") is fine — that is a cross-reference, not a tally.
- **Never write "linked above" / "see the link"** about a companion document. The `.html` *names*
  those files rather than linking them (see *Linking between deliverables*), so navigational
  phrasing is false in exactly the rendering most readers get. Refer to the document by name.
- **Number the rows.** The prose, the divergence paragraph and
  `<study>_literature_comparison.md` all cite claims by number ("Claim 7"), which only works if
  the table numbers them.
- Follow the table with (a) one line naming **which central claims were checked against full
  text** rather than abstracts, and (b) a short **"Where the KG evidence diverges from the
  literature"** paragraph that separates outright **errors in the graphs** from differences of
  **scope**.

Worked example: MS §8 — ten numbered claims, 7 SUPPORTED / 3 PARTIALLY SUPPORTED, followed by the
full-text line and four graph errors called out by claim number.

**Call this a literature *comparison*, never a *validation*.** The verdict is four-way, so
**NOVEL is a finding, not a failure to validate** — and the comparison runs both ways: it just as
often exposes an error in the *graphs* (a mis-assigned drug target, an entity-resolution
collision) as it corroborates a claim. Naming it "validation" casts the literature as the
arbiter and the KG as the defendant, which misreports what the section does.

**Where it lives.** §8 in the report is the *summary* — the claim table, the divergences, and
what was full-text verified. The complete per-claim record with citations goes in a sibling
deliverable, **`<study>_literature_comparison.md`** (not under `data/`, which is for machine
extracts), and §8 **links** to it. Choose the link form by where the report will actually be read —
see *Linking between deliverables* below.

**Every reference in the companion uses the §12 entry format** — `Author, et al. Title. *Journal*.
Year. PMID:… · [doi:…](…)`, plus `— full-text-verified ([PMC…](…))` where applicable — whether the
citations are a consolidated `## References` list or per-claim bullets under each finding. A paper
that is also in the report's §12 **reuses that exact entry** (so its DOI link and full-text/PMC
marker stay identical to the report); a paper cited only in the companion is formatted the same way
from its NCBI `esummary` record. Every inline `[N]` must resolve to a listed entry in the companion
itself — the companion is a standalone document; do not leave `[N]` that only the report's §12 can
resolve. All the §12 rules apply here too (live DOI links, percent-encoded parens, tested links,
preprints labelled).

**Label each finding's outcome *Concordance*, never *Verdict*** — the same word §8's column uses,
for the same reason (the report compares, it does not pass judgement). Write it as
`**Concordance: SUPPORTED.**` (etc.), not `**Verdict: …**`, and **the value is one of the same
closed six** (SUPPORTED / PARTIALLY SUPPORTED / CONTRADICTED / MIXED / NOVEL / UNRESOLVED) — any
per-finding legend the companion carries lists exactly those, and every qualifier lives in the
prose, never in the label.

**Preflight:** this section needs the **PubMed** (`https://pubmed.mcp.claude.com/mcp`) and
**Paperclip** (`https://paperclip.gxl.ai/mcp`) MCP connectors (look for tools named `pubmed` /
`paperclip`). Confirm they're available before writing it; if one is missing, enable it (claude.ai →
Settings → Connectors, or Claude Code `claude mcp add --transport http pubmed
https://pubmed.mcp.claude.com/mcp` / `claude mcp add --transport http paperclip
https://paperclip.gxl.ai/mcp`, then reconnect) or state §8 is **omitted because the connector isn't
enabled** — do not drop it silently. (The full preflight lives in okn-bioanalysis.)

## 9. Full ranked results
Pointer to the xlsx / tsv + the interactive HTML table, and a representative slice table in the
prose. The interactive table must be sortable + paginated, carry a **`sources (n)` corroboration
column** (how many federation KGs support each row, with one pill per source), and expose
**pull-down menus to select the relevant subsets** (e.g. tier, category / type, region, direction,
or any key flag). Add a one-line tip above it explaining sort / filter / paging and what each source
contributes, and **follow the table with a short interpretation** of what the ranking shows.

## 10. Summary of findings & limitations
**The closing narrative section — always end the report here** (Reproducibility and References are
back-matter that follow). Two parts:

- **Findings recap** — 1–3 short paragraphs restating the headline result, the key quantities, and
  the top entities, so a reader who jumps to the end gets the whole story without re-reading.
- **Limitations** — a numbered list of the caveats, uncertainties, and likely undercounts; be
  explicit about what the data cannot support. This is the single home for the caveats list — do not
  duplicate it elsewhere in the report.

## 11. Reproducibility
**Placement is fixed: Reproducibility goes immediately before References, and those two are the
final sections of the report.** Nothing may sit between them, and nothing follows References — a
Reproducibility section that ends the document (with References earlier, or absent) is wrong, as is
a "Sources"/"Deliverables" section appended after them. §10 is the last section a reader reads as
prose; §11 and §12 are back-matter and stay in that order.

**A sentence, the link, and the run command. This section is a signpost, not a summary.** Say that
everything needed to rerun the analysis — the originating prompt, the replicator specification, every
supporting SPARQL query verbatim with the rows it returned, the analysis code, and pinned provenance —
is in the **`<study>_notebook/`** folder (link form per *Linking between deliverables*), that
`<study>_notebook/<study>_notebook.html` shows it executed, and how to open it:

```bash
cd <study>/<study>_notebook
uv run --with jupyterlab --with-requirements requirements.txt jupyter lab <study>_notebook.ipynb
```

(the tool's `run_command`, with the path made relative to the study folder; it needs only
[uv](https://docs.astral.sh/uv/)). Report-building scripts are in `scripts/`, extracts in `data/`.

Do **not** restate the spec here: no enumerated script filenames (`scripts/` is its own listing),
no repeated KG versions (§2 pins them), no timing line, no re-derived counts. Every one of those
already lives in the notebook this section points at, and a second copy is a second thing to keep in
sync. If a fact exists *only* in §11 — a post-hoc re-verification, a corrected quantity — it belongs
in the notebook's specification cell; move it there rather than keeping the section long.

The notebook header still carries the timing, written by `create_jupyter_notebook`: by default the
**study active window** (first→last logged-query wall-clock, UTC — a lower bound that excludes
pre-first-query framing and post-last-query writing); for **whole-chat elapsed time** instead, pass
`chat_started` (ISO-8601 — the server can't know it) and optionally `chat_ended`, giving
`**Elapsed time:** <start>–<end> UTC (<elapsed>)`.

The notebook's header also carries the **model** — `- **Model:** claude-opus-5`, from the required
`model=` argument. The server stores that string verbatim: it cannot see which model is calling it,
so it can neither derive the value nor tell a right one from a wrong one. Pass the **exact runtime
model identifier**, identical to the report title block's (see *Title block* above), and ask the user
if you cannot determine it — a family name, a product name, or an inferred id here silently
mis-attributes the whole analysis.

The header also carries the **skills** that shaped the run — `- **Skills:** okn-bioanalysis
v0.1.3 · okn-report-style v0.2.0` — but only if you pass `skills=[...]`: the server cannot see which
skills your session loaded, so an omitted list silently reads as "no methodology skill was used".
Give each as `"<name> v<version>"`, the version taken from that skill's frontmatter
`metadata.version` (not guessed), and list only skills you actually followed — a skill you didn't use
is a phantom source, exactly like an unqueried KG in §2.

The same is true of the **external MCP servers** the study called — `- **External MCP servers:**
PubMed · Paperclip` — passed as `external_mcp_servers=[...]`. The header's KG list covers only what
came from *this* server; literature and other outside evidence arrived through connectors the server
cannot see, so without this line a replicator reads the KGs as the whole evidence base. List a
connector only if a call to it actually fed the analysis (an enabled-but-unused one is a phantom
source), which is the same set §12's attribution line credits. Token/cost is not captured by the tooling (the
server sees only tool calls); if you cite it, use client figures (Claude Code `/cost` / API
`usage`), labelled as client-measured — do not invent a number.

## 12. References
Open with **exactly this one-line attribution**, then the numbered list — no other preamble:

> Retrieved via the **PubMed** MCP connector. Full-text verification via the **Paperclip** MCP connector.

Use a different line **only** when the analysis genuinely used different tools — e.g. a
regulatory/spatial study that pulled primary documents by WebSearch rather than PubMed/Paperclip
names those instead. Do not add a legend for the `full-text-verified` marker (each entry carries it
inline).

Numbered, and **every literature entry in exactly this shape**:

```
1. Suzuki K, et al. Genetic drivers of heterogeneity in type 2 diabetes pathophysiology. *Nature*. 2024. PMID:38374256 · [doi:10.1038/s41586-024-07019-6](https://doi.org/10.1038/s41586-024-07019-6) — full-text-verified ([PMC10937372](https://pmc.ncbi.nlm.nih.gov/articles/PMC10937372/))
2. Mahajan A, et al. Fine-mapping type 2 diabetes loci to single-variant resolution. *Nat Genet*. 2018. PMID:30297969 · [doi:10.1038/s41588-018-0241-6](https://doi.org/10.1038/s41588-018-0241-6)
```

- `Author, et al.` (first author only; the collective name for a consortium paper) · title · `*Journal*` ·
  year · `PMID:…` · **DOI as a live link**, never bare text.
- **`— full-text-verified` marks only entries actually read in full, and always carries a live link
  to the full text that was read** — the marker without a link claims a verification the reader
  cannot reach. Pick the link by what the full text came from:
  - **In PMC** → the PMC id, linked: `— full-text-verified ([PMC10937372](https://pmc.ncbi.nlm.nih.gov/articles/PMC10937372/))`.
  - **Read through Paperclip** (paywalled journals — *Science*, *NEJM*, *Lancet*, *JNNP* — are
    rarely in PMC) → the Paperclip line-anchored URL the verification produced:
    `— full-text-verified ([full text](https://citations.gxl.ai/…#Lxx))`. **Preserve this URL when you
    mark the entry** — it is the evidence, and it cannot be reconstructed after the fact.
  - Never invent a PMC id, and never downgrade a Paperclip-verified entry to a bare marker because it
    has no PMC — use its Paperclip link. If an entry genuinely has neither (no PMC, no Paperclip
    record), it was not verified against a reachable full text: drop the marker rather than leave it
    linkless.
- **Take every field from the NCBI record**, not from memory or from the prose that cited it:
  `esummary.fcgi?db=pubmed&id=<pmids>&retmode=json` returns title, journal, year, and the `articleids`
  carrying both `doi` and `pmc` in one call. Resolve a missing PMID from the DOI (`"<doi>"[AID]`) or
  the title before writing the entry.
- **Percent-encode `(` and `)` in the DOI link destination** — `%28` / `%29`. Elsevier/Lancet DOIs
  (`10.1016/S1474-4422(08)70173-X`) otherwise terminate the Markdown link at the first `)` and
  silently produce a broken URL, while the same DOI is fine in the HTML `href`. Keep the literal
  parentheses in the visible link text.
- **Test the links before delivering.** A 403 is normal — publishers (NEJM, Lancet, Science, MDPI)
  block automated agents, and `doi.org` still redirects correctly; a **404 or a DNS failure is a
  real defect**, and that is what the check is for.
- **Preprints must be labelled as preprints**, because the entry is also an evidence-quality claim:
  `Author, et al. Title. *Research Square* (preprint — not peer-reviewed). 2023. PMID:… · [doi:…](…)`.
  Use the server's full name (`fulljournalname`, e.g. *Research square*, *bioRxiv*), **never the
  cryptic `source` abbreviation** (`Res Sq`), which reads like an ordinary journal and hides the
  status. NCBI marks them: `pubtype` contains `Preprint`; the DOI prefix is another tell
  (`10.1101` bioRxiv/medRxiv, `10.21203` Research Square, `10.48550` arXiv).
- **A preprint may legitimately have no PMID and no PMC** — only some are in the NIH pilot, and one
  that isn't appears in no NCBI record at all. **The DOI is then the only identifier, and that is
  not a defect**: cite `*<Server>* (preprint — not peer-reviewed). <year>. [doi:…](https://doi.org/…)`
  and stop. Never invent a PMID, and never drop the reference for lacking one.
- **Before citing a preprint, check whether it has since been published** (title search against
  PubMed). If it has, cite the peer-reviewed version; cite the preprint as well only when the claim
  genuinely rests on it, and say which.
- Where a finding depends on preprint-only evidence, **the §8 Concordance cell must say so** — the
  reference's label is not enough on its own, since a reader scanning verdicts never reaches §12.
- Non-paper entries (a search-strategy note, the endpoint/tool citation) stay prose: no PMID, no DOI,
  no invented identifiers.
- **No preamble explaining the marker.** Do not open §12 with a sentence like *"Items marked † (or
  full-text-verified) were checked against full text"* — every entry already carries the marker
  inline, so the sentence only duplicates it (and the retrieval tools are already named in §8). A
  one-line retrieval attribution is fine; a legend for the marker is not.

---

## After building the HTML: verify every section survived

The `.html` is rendered from this Markdown (`build_report_from_markdown`) and is the artifact readers
actually open — so **every section above must appear in it**, especially the unglamorous mandatory
ones (§2 Sources, §8 Comparison with prior work, §10 Limitations) that a condensed or hand-authored
HTML tends to drop. `build_report_from_markdown` **self-verifies** — it runs
`check_report_parity(report_md, report_html)` automatically and prints `[check_report_parity] PASS …`
— so read that line before presenting. If you built the HTML any other way, run it yourself (`python
scripts/build_report_html.py --check report.md report.html`) and see PASS first. It FAILS, naming the
missing sections, if any `##`/`###` heading is absent or the HTML is much shorter than the `.md`.
Passing self-containment / numbers / markup checks is **not** enough — only this confirms the HTML is
the same report. **The report is not delivered until parity PASSES:** treat a FAIL as blocking and
rebuild from the `.md`.

---

## Example figure legends (note the panel refs + provenance)

These come from two different domains to show the pattern is domain-neutral.

> ***Figure 2. PFAS sampling sites and exceedances (sawgraph + spatialkg).*** **(A)** Sampling
> locations on an Esri street basemap, coloured by measured concentration (µg/L); **(B)** counts
> by environmental medium (water / soil / sediment). Provenance: sawgraph PFAS observations joined
> to spatialkg S2 grid cells; coordinates from the sampled features.

> ***Figure 4. Category enrichment (prokn, symbol-bridged).*** Top 20 of N categories at FDR < 0.05,
> ranked by significance; bars coloured by theme, annotated with fold and (hits / category size).
> Foreground = … ; background = … ; hypergeometric + Benjamini–Hochberg FDR. Provenance: prokn
> Gene → `encodes` → Protein → `involved in` → GO. Bridged, lower-confidence.

Notes that keep legends useful and standalone:
- Name every panel letter you use.
- Give the statistical test (if any), the foreground / background, and any multiple-testing correction.
- State the exact KG + predicate path (provenance) so a reader can reproduce the panel.
- For maps: name the basemap (Esri World Street Map), the coordinate source, and what each marker / colour encodes.
- If a symbol / letter appears in the plot, define it here.
- **Follow every figure legend — and every table — with a short interpretation of the result** (what
  it means / the takeaway), in the body text below; never inside the legend or the PNG.
